<?php

 $_USERS = array (
  0 => 
  array (
    'name' => 'Admin',
    'pass' => '$1$K9T1P0JB$NpHQrGXvqWkR40M8csnjA0',
    'role' => 'superadmin',
  ),
);
