--help neural
require('neural').setup({
    source = {
        openai = {
          api_key = "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",
        },
    },
})
