--help neural
require('neural').setup({
    source = {
        openai = {
          api_key = "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",
        },
    },
})
