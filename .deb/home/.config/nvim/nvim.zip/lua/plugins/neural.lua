--help neural
require('neural').setup({
    source = {
        openai = {
            api_key = OPENAI_KEY,
        },
    },
})
