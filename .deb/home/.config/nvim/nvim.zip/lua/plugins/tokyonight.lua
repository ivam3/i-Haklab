--vim.cmd[[colorscheme tokyonight-moon]]
vim.g.tokyonight_transparent = vim.g.transparent_enabled
