-- Configuración para el plugin ollama.nvim
local M = {}

function M.setup()
  require("ollama").setup({
    -- =====================================================
    -- CONFIGURACIÓN PRINCIPAL (AJUSTA SEGÚN TUS NECESIDADES)
    -- =====================================================

    -- Modelo por defecto (debe estar descargado en tu sistema)
    model = "deepseek-coder:1.3b", -- O el que tengas, ej: "mistral", "codellama"

    -- URL del servidor de Ollama (por defecto localhost)
    url = "http://127.0.0.1:11434",

    -- Configuración para iniciar/detener el servidor Ollama
    serve = {
      on_start = false, -- Cambia a true si quieres que inicie al abrir Neovim
      command = "ollama",
      args = { "serve" },
      stop_command = "pkill",
      stop_args = { "-SIGTERM", "ollama" },
    },

    -- =====================================================
    -- PROMPTS PERSONALIZADOS (EJEMPLOS)
    -- =====================================================
    prompts = {
      -- Puedes añadir tus propios prompts aquí
      -- Ejemplo: Prompt para explicar código
      Explain_Code = {
        prompt = "Explica el siguiente código en español de forma clara y concisa:\n\n$sel",
        input_label = "Pregunta adicional (opcional): ",
        action = "display",
        model = "llama3.2", -- Puedes sobreescribir el modelo para este prompt
        options = {
          temperature = 0.3,
        },
      },
      -- Ejemplo: Prompt para generar código
      Generate_Code = {
        prompt = "Genera código $ftype para: $input",
        input_label = "Descripción de la tarea: ",
        action = "display_insert",
        model = "codellama",
        extract = "```$ftype\n(.-)```",
        options = {
          temperature = 0.2,
        },
      },
      -- Para deshabilitar un prompt por defecto:
      -- Sample_Prompt = false,
    },
  })

  -- =====================================================
  -- ATAJOS DE TECLADO ADICIONALES (OPCIONAL)
  -- =====================================================
  -- Puedes definir atajos de teclado específicos aquí también
  -- vim.keymap.set("n", "<leader>op", ":lua require('ollama').prompt()<CR>", { desc = "Ollama: Abrir menú de prompts" })
  -- vim.keymap.set("v", "<leader>oe", ":lua require('ollama').prompt('Explain_Code')<CR>", { desc = "Ollama: Explicar código seleccionado" })
end

-- =====================================================
-- INTEGRACIÓN CON LUALUINE (OPCIONAL)
-- =====================================================
-- Esto agregará un indicador en tu barra de estado (lualine)
-- cuando el servidor de Ollama esté procesando una solicitud.
--
-- Si usas lualine (que ya tienes instalado), puedes agregar esta
-- función a tu configuración de lualine en el archivo correspondiente.
--
-- Ejemplo de cómo se vería en tu archivo 'plugins/lualine.lua':
--
-- local function ollama_status()
--   local status_ok, ollama = pcall(require, "ollama")
--   if not status_ok then return "" end
--   local status = ollama.status()
--   if status == "IDLE" then
--     return "󱙺" -- Icono de robot inactivo
--   elseif status == "WORKING" then
--     return "󰚩" -- Icono de robot procesando
--   end
--   return ""
-- end
--
-- Luego, en la configuración de lualine, añadirías:
-- lualine_x = { ollama_status, ... }

return M
