require('mason').setup({})
require('mason-lspconfig').setup({
  automatic_installation = false,
})

local lsp_servers = {
  jdtls = {
        cmd = { 'jdtls' }, -- :MasonInstall jdtls
        filetypes = { 'java' },
        root_dir = require('lspconfig.util').root_pattern('pom.xml', 'build.gradle', '.git'),
    },
  bashls = {
    cmd = { 'bash-language-server', 'start' },
    filetypes = { 'bash', 'sh' },
  },
  clangd = {
    cmd = { 'clangd' },
    filetypes = { 'c', 'cpp', 'objc', 'objcpp', 'cuda', 'proto' },
  },
  pyright = {
    cmd = { 'pyright-langserver', '--stdio' },
    filetypes = { 'python' },
  },
  lua_ls = {
    cmd = { '/data/data/com.termux/files/usr/bin/lua-language-server' },
    filetypes = { 'lua' },
    settings = {
      Lua = {
        runtime = { version = 'LuaJIT' },
        diagnostics = { globals = { 'vim' } },
        workspace = { library = { vim.env.VIMRUNTIME } },
      },
    },
  },
  smali_lsp = {
    cmd = { 'smali-lsp', 'lsp' },
    filetypes = { 'smali' },
  },
}

local capabilities = vim.lsp.protocol.make_client_capabilities()
capabilities = vim.tbl_deep_extend('force', capabilities,
  require('cmp_nvim_lsp').default_capabilities())

for name, config in pairs(lsp_servers) do
  vim.api.nvim_create_autocmd('FileType', {
    pattern = config.filetypes,
    callback = function(args)
      local clients = vim.lsp.get_clients({ name = name, bufnr = args.buf })
      if #clients == 0 then
        vim.lsp.start({
          name = name,
          cmd = config.cmd,
          capabilities = capabilities,
          settings = config.settings,
          on_attach = function(client, bufnr)
            -- no-op, keymaps set globally via LspAttach below
          end,
        })
      end
    end,
  })
end

vim.api.nvim_create_autocmd('VimEnter', {
  once = true,
  callback = function()
    vim.api.nvim_exec_autocmds('FileType', { buffer = 0 })
  end,
})

vim.diagnostic.config({
  virtual_text = true,
  signs = true,
  update_in_insert = false,
  underline = true,
  severity_sort = true,
  float = true,
})

vim.api.nvim_create_autocmd('LspAttach', {
  desc = 'LSP actions',
  callback = function(args)
    local bufmap = function(mode, lhs, rhs)
      local opts = { buffer = args.buf }
      vim.keymap.set(mode, lhs, rhs, opts)
    end
    bufmap('n', 'K', '<cmd>lua vim.lsp.buf.hover()<cr>')
    bufmap('n', 'gd', '<cmd>lua vim.lsp.buf.definition()<cr>')
    bufmap('n', 'gD', '<cmd>lua vim.lsp.buf.declaration()<cr>')
    bufmap('n', 'gi', '<cmd>lua vim.lsp.buf.implementation()<cr>')
    bufmap('n', 'go', '<cmd>lua vim.lsp.buf.type_definition()<cr>')
    bufmap('n', 'gr', '<cmd>lua vim.lsp.buf.references()<cr>')
    bufmap('n', 'gs', '<cmd>lua vim.lsp.buf.signature_help()<cr>')
    bufmap('n', '<F3>', '<cmd>lua vim.lsp.buf.rename()<cr>')
    bufmap('n', '<F4>', '<cmd>lua vim.lsp.buf.code_action()<cr>')
    -- bufmap('x', '<F4>', '<cmd>lua vim.lsp.buf.range_code_action()<cr>')
    bufmap('x', '<F4>', function() vim.lsp.buf.code_action() end)
    bufmap('n', 'gl', '<cmd>lua vim.diagnostic.open_float()<cr>')
    bufmap('n', '[d', '<cmd>lua vim.diagnostic.jump({ count = -1 })<cr>')
    bufmap('n', ']d', '<cmd>lua vim.diagnostic.jump({ count = 1 })<cr>')
    -- Aportes demon (leaders libres, no pisan los actuales)
    bufmap('n', '<leader>rn', '<cmd>lua vim.lsp.buf.rename()<cr>')
    bufmap('n', '<leader>ca', '<cmd>lua vim.lsp.buf.code_action()<cr>')
    bufmap('n', '<leader>ds', '<cmd>lua vim.lsp.buf.document_symbol()<cr>')
    bufmap('n', '<leader>ci', '<cmd>lua vim.lsp.buf.incoming_calls()<cr>')
    bufmap('n', '<leader>co', '<cmd>lua vim.lsp.buf.outgoing_calls()<cr>')
  end
})

vim.opt.completeopt = { 'menu', 'menuone', 'noselect' }

workspace = {
  checkThirdParty = false,
  library = vim.api.nvim_get_runtime_file("", true),
},


require('luasnip.loaders.from_vscode').lazy_load()

local cmp = require('cmp')
local luasnip = require('luasnip')

cmp.setup({
  sources = {
    { name = 'nvim_lsp' },
    { name = 'path' },
    { name = 'buffer' },
    { name = 'luasnip' },
  },
  mapping = cmp.mapping.preset.insert({
    ['<C-p>'] = cmp.mapping.select_prev_item({ behavior = 'select' }),
    ['<C-n>'] = cmp.mapping.select_next_item({ behavior = 'select' }),
    ['<C-u>'] = cmp.mapping.scroll_docs(-4),
    ['<C-d>'] = cmp.mapping.scroll_docs(4),
    ['<CR>'] = cmp.mapping.confirm({ select = true }),
  }),
  snippet = {
    expand = function(args)
      luasnip.lsp_expand(args.body)
    end
  },
  window = {
    documentation = cmp.config.window.bordered()
  },
  formatting = {
    fields = { 'menu', 'abbr', 'kind' },
    format = function(entry, item)
      local menu_icon = {
        nvim_lsp = 'λ',
        luasnip = '⋗',
        buffer = 'Ω',
        path = '',
        nvim_lua = "Π",
      }
      item.menu = menu_icon[entry.source.name]
      return item
    end,
  },
})
