
-- configuraciones predeterminadas
require('git').setup()

