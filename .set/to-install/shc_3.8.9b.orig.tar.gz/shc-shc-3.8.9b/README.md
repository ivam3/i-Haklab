# shc

This is the public `shc` source repo, maintained by the `shc` Debian package maintainer, as the original author is not maintaining the package any more -- Details enclosed below:

> From: Javier Fafián Álvarez @gmail.com  
> Date: Tue, Sep 8, 2015 at 11:11 AM  
> Subject: shc 3.8.9 fixed!  
> To: Tong Sun @cpan.org  
> 
> I get another email and he [the original author] answer me -in spanish- **he can't maintain the package any more** but he can help with some bug fixes, and it looks like he fixed it!:
> 
> http://www.datsi.fi.upm.es/~frosal/sources/shc-3.8.9b.tgz
> 
> Great! :)

This public `shc` source repo contains the `shc` version from its first Debian release, v3.8.7, to the lastest (shc-3.8.9 & shc-3.8.9b).

