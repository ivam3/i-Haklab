---
name: Question 🤔
about: Usage question or discussion about Metasploit.
labels: "question"
---

<!--
  To make it easier for us to help you, please include as much useful information as possible.

  Useful Links:
  - Wiki: https://github.com/rapid7/metasploit-framework/wiki

  Before opening a new issue, please search existing issues https://github.com/rapid7/metasploit-framework/issues
-->

## Summary

## Relevant information

<!-- Provide as much useful information as you can -->
